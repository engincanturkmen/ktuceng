# Verilen sayıların faktoriyelini bulma
def faktöriyel(n): 
      
    # Tek satırda faktöriyel bulma
    return 1 if (n==1 or n==0) else n * faktöriyel(n - 1);  
  
num = 8; 
print("Faktöriyel değeri:",num,"için", 
faktöriyel(num)) 
# Recursive olarak verilen sayının faktoriyelini hesaplama
  